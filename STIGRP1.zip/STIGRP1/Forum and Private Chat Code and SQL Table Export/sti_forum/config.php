<?php

//login to sql
mysql_connect('localhost', 'root', '');
mysql_select_db('stiforum');

$admin='admin';

//Forum Home Page
$url_home = 'index.php';

//Design Name
$design = 'default';

include('init.php');

$tz = 'Asia/Singapore';
?>