-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2016 at 04:23 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stiforum`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` smallint(6) NOT NULL,
  `name` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `position` smallint(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `position`) VALUES
(1, 'Cyber Bullying', 'Bullying through the use of information and communication technologies (ICT)', 1),
(2, 'Online Addiction', 'Online gaming or gambling compulsive behaviour', 4),
(6, 'Online Copyright ', 'Rights and the fair use of work from other authors and creators', 5),
(4, 'Handling Inappropriate Content', 'Issues pertaining to the handling of inappropriate content', 7),
(5, 'Cyber Safety', 'The safe and responsible use of ICT to protect personal data and reputation', 2),
(7, 'Cyber Security', 'The protection of one''s cyber environment against the criminal or unauthorised use of electronic data ', 3),
(8, 'Online Netiquette ', 'The right behaviour on the internet to always maintain civility', 6);

-- --------------------------------------------------------

--
-- Table structure for table `pm`
--

CREATE TABLE `pm` (
  `id` bigint(20) NOT NULL,
  `id2` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `user1` bigint(20) NOT NULL,
  `user2` bigint(20) NOT NULL,
  `message` text NOT NULL,
  `timestamp` int(10) NOT NULL,
  `user1read` varchar(3) NOT NULL,
  `user2read` varchar(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pm`
--

INSERT INTO `pm` (`id`, `id2`, `title`, `user1`, `user2`, `message`, `timestamp`, `user1read`, `user2read`) VALUES
(2, 4, '', 2, 0, 'Wow! Thanks for the heads up', 1464929605, '', ''),
(6, 1, 'Forum Update', 6, 5, 'A patch is coming soon at ......', 1464929641, 'yes', 'yes'),
(2, 1, 'Thanks for your contribution', 5, 2, 'We from the Cyber Warriors team want to thank you for your help!', 1464929348, 'yes', 'yes'),
(2, 2, '', 2, 0, 'No problem. I love this community and will continue to provide help for those who need it', 1464929405, '', ''),
(2, 3, '', 5, 0, 'Good luck! know that we are watching an who knows, you might be promoted to a moderator:)', 1464929445, '', ''),
(5, 1, 'Need advice ', 3, 5, 'I need some advice regarding this issue.......', 1464929520, 'yes', 'yes'),
(7, 1, 'Feedback Update', 1, 5, 'Feedback here......', 1464929708, 'yes', 'yes'),
(6, 2, '', 5, 0, 'Will look', 1464929730, '', ''),
(5, 2, '', 5, 0, 'Advice here', 1464929742, '', ''),
(5, 3, '', 5, 0, 'And here....', 1464929749, '', ''),
(5, 4, '', 5, 0, 'Also don&#039;t forget here....', 1464929764, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE `topics` (
  `parent` smallint(6) NOT NULL,
  `id` int(11) NOT NULL,
  `id2` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `message` longtext NOT NULL,
  `authorid` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `timestamp2` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`parent`, `id`, `id2`, `title`, `message`, `authorid`, `timestamp`, `timestamp2`) VALUES
(1, 2, 2, '', 'Hi Cillary Hlinton,<br />\r\n<br />\r\n<strong>You and Mehico should report the events that transpired to your teacher or parents. Do not be afraid of Tonald Drump, however do not provoke him. Your teachers/parents will know how to handle the rest. You and your friend will be fine :)</strong><br />\r\n<br />\r\nTake Care,<br />\r\nCounsellor1', 5, 1464503634, 1464503634),
(1, 2, 1, 'I need advice on a difficult situation', 'Hi guys, <br />\r\nI&#039;am here today to seek some advice on what I should do, the names mentioned are not their real names.<br />\r\n<br />\r\n Recently my friend Mehico, has been cyber bullied on Facebook by his classmate, Donald Trumpet. I&#039;am not sure if I should tell his parents/teachers or remain quiet. I&#039;am afraid that Donald Trumpet will come after me if I report him.', 3, 1464503167, 1464503955),
(1, 2, 3, '', 'Cillary Hlinton, this happened to me about a year ago and I agree that the best way to handle this situation would be to report it to someone with higher authority. ', 2, 1464503832, 1464503832),
(1, 2, 4, '', 'Hi guys, and update:<br />\r\n<br />\r\nI did what you guys said and its all over and better now. The bullying has stopped and it&#039;s all good. Thank you guys for the advice, it really helped a lot!! :D', 3, 1464503955, 1464503955),
(1, 3, 1, 'I CANT TAKE IT ANYMORE', 'I have been cyber bullied for the past year and I can&#039;t take it anymore. It feels like no one cares.', 2, 1464504208, 1464579072),
(1, 3, 2, '', 'Hi Sherlock NoHome. <br />\r\n<br />\r\nThere are a ton of people who care about you. They just do not know the situation you are in. You should tell them about what is happening and feel free to chat with one of us Counsellors here too. Thousands of people are going through same thing as you. The best thing to do now is to tell parents or friends and express what you feel. Things will only get better from now. Do not feel small because of the comments made by others. <br />\r\n<br />\r\n<strong><div style="text-align:center;">You are special! Do not let anyone tell you otherwise.</div></strong><br />\r\n<br />\r\nLook at the long way you still have. Conquer this obstacle and keep running forward :)<br />\r\nBe well,<br />\r\nCounsellor2 ', 6, 1464504592, 1464504592),
(1, 3, 3, '', 'Thanks for the reply. It really helped me!<br />\r\nCan I send you a private message?<br />\r\n<br />\r\nThanks', 2, 1464578401, 1464578401),
(1, 3, 4, '', 'Of course you can! Hit me up anytime you need help or a person to talk to:)<br />\r\n<br />\r\nCounsellor2', 6, 1464578580, 1464578580),
(1, 3, 5, '', '<img src="http://quoteshunter.com/wp-content/uploads/2015/05/Quotes-to-make-you-smile-9.jpg" alt="Image" />', 6, 1464578824, 1464578824),
(1, 3, 6, '', '<div style="text-align:center;">Hi, here&#039;s something to help you which helped me! :D</div><br />\r\n<br />\r\n<div style="text-align:right;"><span style="text-decoration:underline;"><strong>Stay Positive Quotes</strong></span><br />\r\n<a href="http://www.goodreads.com/quotes/tag/positivity">http://www.goodreads.com/quotes/tag/positivity</a></div>', 3, 1464579072, 1464579072),
(1, 7, 1, 'Useful links for parents and teachers here!', 'Links Here: <br />\r\n...', 3, 1464928053, 1464928053),
(1, 5, 1, 'Ways to have a healthy cyber life', 'To lead a healthy cyber life.....', 5, 1464927812, 1464927812),
(1, 6, 1, 'Feel free to message us counsellors!', 'Always here to help. Contacts are:<br />\r\n...', 6, 1464927962, 1464927962);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `signup_date` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `signup_date`) VALUES
(1, 'admin', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'admin@cw.com', 1464269430),
(2, 'Sherlock NoHome', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'snh@testmail.com', 1464269888),
(3, 'Cillary Hlinton', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'ch@testmail.com', 1464269913),
(4, '<script>alert("Hi");</script>', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'abc@abc.com', 1464423234),
(5, 'Counsellor1', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'c1@c.com', 1464503300),
(6, 'Counsellor2', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'c2@c.com', 1464503316);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`id`,`id2`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
