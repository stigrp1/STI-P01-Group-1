This ionic pages includes: 
homepage, private chat pages, 
quote pages, 
cyber wellness resource page sand upcoming events pages